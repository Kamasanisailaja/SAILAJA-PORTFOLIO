# Portfolio

# About me
        - Lakshmi Narayana Velayudam
        - Pursuing B.Tech 4th year (2023 passout)
        - Tirupati, India
        - Skills: C, C++, Java, Python, SQL, DSA        
# Contact
- <a href="https://www.linkedin.com/in/lakshmi-narayana-velayudam/">LinkedIn</a> 
 - <a href="mailto: lcchinnu@gmail.com">Mail</a>


